import { createContext, useContext, useState } from "react";
import { notify } from "../utils/toast";

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

const parseToken = (token) => {
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    return {
      username: payload.username,
      isAdmin: payload.is_staff,
    };
  } catch {
    return null;
  }
};

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(() => localStorage.getItem("token"));

  const [user, setUser] = useState(() => {
    const storedToken = localStorage.getItem("token");
    return storedToken ? parseToken(storedToken) : null;
  });

  const login = (newToken) => {
    if (!newToken) return;

    localStorage.setItem("token", newToken);

    const parsedUser = parseToken(newToken);
    setUser(parsedUser);
    setToken(newToken);
  };

  const logout = () => {
    localStorage.removeItem("token");
    notify.info("Logged Out!");
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ token, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};