import axios from "axios";
import API_BASE from "../api/base";
import { notify } from "../utils/toast";

const api = axios.create({
  baseURL: API_BASE,
});


// -------------------------------
// REQUEST INTERCEPTOR
// -------------------------------
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => Promise.reject(error)
);


// -------------------------------
// RESPONSE INTERCEPTOR
// -------------------------------
api.interceptors.response.use(
  (response) => response,

  (error) => {
    // Skip toast if explicitly disabled
    if (error.config?.skipToast) {
      return Promise.reject(error);
    }

    let message = "Something went wrong";

    if (error.response) {
      const data = error.response.data;

      if (data?.detail) {
        message = data.detail;
      } else if (data?.error) {
        message = data.error;
      } else if (typeof data === "object") {
        message = Object.values(data).flat().join(" ");
      }

      // Handle unauthorized
      if (error.response.status === 401) {
        localStorage.removeItem("token");

        // Prevent infinite redirect loop
        if (window.location.pathname !== "/login") {
          window.location.href = "/login";
        }
      }

    } else if (error.request) {
      message = "Network error. Server not reachable.";
    }

    notify.error(message);

    return Promise.reject(error);
  }
);

export default api;