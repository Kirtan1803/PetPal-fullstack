import { useEffect, useState } from "react";
import api from "../services/api";
import { notify } from "../utils/toast";

function MyAdoptions() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAdoptions();
  }, []);

  const fetchAdoptions = async () => {
    try {
      setLoading(true);
      const res = await api.get("/adoption/my/");
      setData(Array.isArray(res.data) ? res.data : []);
    } catch {
      notify.error("Failed to load adoptions");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 className="mb-4">My Adoptions</h2>

      {loading ? (
        <p>Loading...</p>
      ) : data.length === 0 ? (
        <p>No adoption requests found</p>
      ) : (
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Pet</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>

          <tbody>
            {data.map((item) => (
              <tr key={item.id}>
                <td>{item.pet_name}</td>
                <td>
                  {item.status
                    ? item.status.charAt(0).toUpperCase() +
                      item.status.slice(1)
                    : "-"}
                </td>
                <td>{item.created_at || "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default MyAdoptions;