import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../services/api";
import { notify } from "../utils/toast";

function PetDetails() {
  const { id } = useParams();
  const [pet, setPet] = useState(null);
  const [message, setMessage] = useState("");
  const [requestSent, setRequestSent] = useState(false);

  useEffect(() => {
    const fetchPet = async () => {
      try {
        const res = await api.get(`/pets/${id}/`);
        setPet(res.data);
      } catch (err) {
        notify.error("Failed to load pet details");
      }
    };

    fetchPet();
  }, [id]);

  const getImage = (img) => {
    if (!img) return "/assets/img/images/default_pet.png";
    if (img.startsWith("http")) return img;
    return `http://127.0.0.1:8000${img}`;
  };

  const handleAdopt = async () => {
    if (!message.trim()) {
      notify.error("Please enter a message");
      return;
    }

    try {
      await notify.promise(
        api.post(
          "/adoption/request/",
          { pet: Number(id), message },
          { skipToast: true }
        ),
        {
          pending: "Sending request...",
          success: "Request sent 🐾",
          error: {
            render({ data }) {
              const err = data?.response?.data;

              if (!err) return "Something went wrong";

              if (typeof err === "object") {
                return Object.values(err).flat().join(" ");
              }

              return err;
            },
          },
        }
      );

      setRequestSent(true);
    } catch (err) {
      // handled by toast
    }
  };

  if (!pet) return <p>Loading...</p>;

  return (
    <section className="animal__details-area pt-0 pb-100">
      <div className="container">
        <div className="row">
          {/* IMAGE */}
          <div className="col-lg-6">
            <div className="pet-image-wrapper">
              <img
                src={getImage(pet.image)}
                alt={pet.name}
                className="img-fluid rounded shadow"
              />
            </div>
          </div>

          {/* INFO */}
          <div className="col-lg-6">
            <div className="animal__details-sidebar-info">
              <h2 className="title mb-2">{pet.name}</h2>

              <p className="text-muted mb-3">
                {pet.category_name || "Pet"} • {pet.age} years
              </p>

              <ul className="list-wrap mb-4">
                <li>
                  <span>Color:</span> {pet.color}
                </li>
                <li>
                  <span>Status:</span>{" "}
                  {pet.status
                    ? pet.status.charAt(0).toUpperCase() +
                      pet.status.slice(1)
                    : "Available"}
                </li>
              </ul>

              <textarea
                className="form-control no-resize"
                placeholder="Why do you want to adopt?"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />

              <button
                className="btn w-100 mt-3"
                onClick={handleAdopt}
                disabled={requestSent}
              >
                {requestSent ? "Request Sent" : "Send Adoption Request"}
              </button>
            </div>
          </div>
        </div>

        {/* DESCRIPTION */}
        <div className="animal__details-description mt-5">
          <h4 className="title">Description</h4>
          <p>{pet.description || "No description available."}</p>
        </div>
      </div>
    </section>
  );
}

export default PetDetails;