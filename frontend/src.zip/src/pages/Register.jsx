import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import api from "../services/api";
import AuthLayout from "../components/AuthLayout";
import { notify } from "../utils/toast";

function Register() {
  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
  });

  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    if (!form.username || !form.email || !form.password) {
      notify.error("Please fill all fields");
      return;
    }

    try {
      await api.post("/auth/register/", form);
      notify.success("Registered successfully!");
      navigate("/login");
    } catch (err) {
      // handled by interceptor
    }
  };

  return (
    <AuthLayout>
      <div className="text-center mb-3">
        <img src="/assets/logo.png" alt="logo" style={{ width: "300px" }} />
        <h4 className="mt-0 fw-bold">Create Account</h4>
      </div>

      <form onSubmit={handleRegister}>
        <input
          className="form-control mb-3"
          placeholder="Username"
          value={form.username}
          onChange={(e) =>
            setForm({ ...form, username: e.target.value })
          }
        />

        <input
          className="form-control mb-3"
          placeholder="Email"
          value={form.email}
          onChange={(e) =>
            setForm({ ...form, email: e.target.value })
          }
        />

        <div className="input-group mb-3">
          <input
            type={showPassword ? "text" : "password"}
            className="form-control"
            placeholder="Password"
            value={form.password}
            onChange={(e) =>
              setForm({ ...form, password: e.target.value })
            }
          />

          <span
            className="input-group-text"
            style={{ cursor: "pointer" }}
            onClick={() => setShowPassword((prev) => !prev)}
          >
            <i
              className={`fas ${showPassword ? "fa-eye-slash" : "fa-eye"}`}
            ></i>
          </span>
        </div>

        <button
          type="submit"
          className="btn w-100 mt-2 fw-semibold d-flex justify-content-center align-items-center"
          style={{
            background: "linear-gradient(135deg, #1e293b, #0f172a)",
            color: "white",
            border: "none",
            borderRadius: "8px",
            padding: "10px",
          }}
        >
          Register
        </button>
      </form>

      <p className="text-center mt-3">
        Already have an account? <Link to="/login">Login</Link>
      </p>
    </AuthLayout>
  );
}

export default Register;