import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";
import AuthLayout from "../components/AuthLayout";
import { notify } from "../utils/toast";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    if (!email || !password) {
      notify.error("Please fill all fields");
      return;
    }

    try {
      const res = await api.post("/auth/login/", {
        username: email,
        password,
      });

      login(res.data.access);
      notify.success("Login successful 🎉");
      navigate("/");
    } catch (err) {
      // Avoid duplicate toast (handled by interceptor)
    }
  };

  return (
    <AuthLayout>
      <div className="text-center mb-3">
        <img src="/assets/logo.png" alt="logo" style={{ width: "300px" }} />
        <h4 className="mt-0 fw-bold">Welcome Back</h4>
      </div>

      <form onSubmit={handleLogin}>
        <input
          className="form-control mb-3"
          placeholder="Email / Username"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <div className="input-group mb-3">
          <input
            type={showPassword ? "text" : "password"}
            className="form-control"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <span
            className="input-group-text"
            style={{ cursor: "pointer" }}
            onClick={() => setShowPassword((prev) => !prev)}
          >
            <i
              className={`fas ${showPassword ? "fa-eye-slash" : "fa-eye"}`}
            ></i>
          </span>
        </div>

        <button
          className="btn w-100 mt-2 fw-semibold d-flex justify-content-center align-items-center"
          type="submit"
          style={{
            background: "linear-gradient(135deg, #1e293b, #0f172a)",
            color: "white",
            border: "none",
            borderRadius: "8px",
            padding: "10px",
          }}
        >
          Login
        </button>
      </form>

      <p className="text-center mt-3">
        New user? <Link to="/register">Register</Link>
      </p>
    </AuthLayout>
  );
}

export default Login;