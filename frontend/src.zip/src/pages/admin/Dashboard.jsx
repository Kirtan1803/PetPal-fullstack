import { useEffect, useState } from "react";
import api from "../../services/api";
import { notify } from "../../utils/toast";

function Dashboard() {
  const [pets, setPets] = useState([]);
  const [adoptions, setAdoptions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      const [petsRes, adoptionRes] = await Promise.all([
        api.get("/pets/"),
        api.get("/adoption/requests/"),
      ]);

      setPets(Array.isArray(petsRes.data) ? petsRes.data : []);
      setAdoptions(Array.isArray(adoptionRes.data) ? adoptionRes.data : []);
    } catch {
      notify.error("Failed to load dashboard");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="p-4">Loading dashboard...</div>;
  }

  // Metrics
  const totalPets = pets.length;
  const availablePets = pets.filter(
    (p) => p.status === "available"
  ).length;
  const adoptedPets = pets.filter(
    (p) => p.status === "adopted"
  ).length;

  const pendingRequests = adoptions.filter(
    (a) => a.status === "pending"
  ).length;

  return (
    <div className="admin-dashboard">
      {/* METRIC CARDS */}
      <div className="dashboard-cards">
        <div className="card-box">
          <h6>Total Pets</h6>
          <h2>{totalPets}</h2>
        </div>

        <div className="card-box">
          <h6>Available</h6>
          <h2>{availablePets}</h2>
        </div>

        <div className="card-box">
          <h6>Adopted</h6>
          <h2>{adoptedPets}</h2>
        </div>

        <div className="card-box">
          <h6>Pending Requests</h6>
          <h2>{pendingRequests}</h2>
        </div>
      </div>

      {/* RECENT ADOPTIONS */}
      <div className="dashboard-section">
        <h5>Recent Adoption Requests</h5>

        <div className="table-box">
          <table>
            <thead>
              <tr>
                <th>Pet</th>
                <th>User</th>
                <th>Status</th>
              </tr>
            </thead>

            <tbody>
              {adoptions.slice(0, 5).map((a) => (
                <tr key={a.id}>
                  <td>{a.pet_name}</td>
                  <td>{a.user}</td>
                  <td className={`status ${a.status}`}>
                    {a.status
                      ? a.status.charAt(0).toUpperCase() +
                        a.status.slice(1)
                      : "-"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;