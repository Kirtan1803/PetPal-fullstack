import { useEffect, useState } from "react";
import api from "../../services/api";
import { notify } from "../../utils/toast";

function PetRequests() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    try {
      setLoading(true);
      const res = await api.get("/pets/admin/");
      setRequests(Array.isArray(res.data) ? res.data : []);
    } catch {
      notify.error("Failed to load pet requests");
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id) => {
    try {
      await api.post(`/pets/approve/${id}/`);
      notify.success("Pet approved");

      setRequests((prev) => prev.filter((r) => r.id !== id));
    } catch {
      notify.error("Approval failed");
    }
  };

  const handleReject = async (id) => {
    try {
      await api.post(`/pets/reject/${id}/`);
      notify.success("Pet rejected");

      setRequests((prev) => prev.filter((r) => r.id !== id));
    } catch {
      notify.error("Rejection failed");
    }
  };

  if (loading) {
    return <div className="p-4">Loading requests...</div>;
  }

  return (
    <div className="admin-dashboard">
      <div className="dashboard-section">
        <h5>Pet Requests</h5>

        <div className="table-box">
          <table>
            <thead>
              <tr>
                <th>Pet</th>
                <th>Category</th>
                <th>Owner</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {requests.length === 0 ? (
                <tr>
                  <td colSpan="5" style={{ textAlign: "center" }}>
                    No pending requests
                  </td>
                </tr>
              ) : (
                requests.map((pet) => (
                  <tr key={pet.id}>
                    <td>{pet.name}</td>
                    <td>{pet.category_name || "-"}</td>
                    <td>{pet.owner_email || "-"}</td>

                    <td className="status pending">Pending</td>

                    <td className="action-cell">
                      <button
                        className="btn-approve"
                        onClick={() => handleApprove(pet.id)}
                      >
                        Approve
                      </button>

                      <button
                        className="btn-reject"
                        onClick={() => handleReject(pet.id)}
                      >
                        Reject
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default PetRequests;