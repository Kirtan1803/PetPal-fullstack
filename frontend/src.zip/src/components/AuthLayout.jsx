import { useEffect } from "react";

function AuthLayout({ children }) {

  useEffect(() => {
    // Remove template layout classes that cause spacing
    document.body.classList.remove("header-fixed");
    document.body.classList.remove("topbar-fixed");

    // Hard reset body spacing
    document.body.style.paddingTop = "0px";
    document.body.style.marginTop = "0px";

    return () => {
      // Optional: restore if needed later
      document.body.style.paddingTop = "";
      document.body.style.marginTop = "";
    };
  }, []);

  return (
    <div
      className="d-flex align-items-center justify-content-center auth-wrapper"
      style={{
        minHeight: "100vh",
        background: "linear-gradient(to right, #eef2f7, #f8fafc)",
      }}
    >
      <div
        className="card shadow-sm p-4 border-0"
        style={{
          width: "380px",
          borderRadius: "16px",
        }}
      >
        {children}
      </div>
    </div>
  );
}

export default AuthLayout;