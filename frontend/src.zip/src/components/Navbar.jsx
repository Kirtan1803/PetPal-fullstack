import { Link, NavLink, useNavigate } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";

function Navbar() {
  const navigate = useNavigate();
  const headerRef = useRef(null);
  const notifRef = useRef(null);

  const { user, logout } = useAuth();

  const [notifications, setNotifications] = useState([]);
  const [open, setOpen] = useState(false);

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  const fetchNotifications = async () => {
    try {
      const res = await api.get("/notifications/");
      setNotifications(Array.isArray(res.data) ? res.data : []);
    } catch {
      // silent fail (avoid spam)
    }
  };

  useEffect(() => {
    fetchNotifications();

    const interval = setInterval(fetchNotifications, 15000);
    return () => clearInterval(interval);
  }, []);

  const markAsRead = async (id) => {
    try {
      await api.patch(`/notifications/${id}/read/`);

      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)),
      );
    } catch {
      // silent
    }
  };

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const header = headerRef.current;
      if (!header) return;

      if (window.scrollY > 60) {
        header.classList.add("shrink");
      } else {
        header.classList.remove("shrink");
      }
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header className="tg-header custom-navbar" ref={headerRef}>
      {/* TOP BAR */}
      <div className="tg-header__top">
        <div className="container-fluid">
          <div className="row">
            <div className="col-lg-6">
              <ul className="tg-header__top-info list-wrap">
                <li>👤 Hi, {user?.username || "User"}</li>
              </ul>
            </div>

            <div className="col-lg-6">
              <ul className="tg-header__top-right list-wrap">
                <li>
                  <Link to="/my-adoptions">🐾 My Requests</Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* MAIN NAV */}
      <div className="tg-header__area">
        <div className="container-fluid">
          <div className="tgmenu__nav">
            {/* LOGO */}
            <div className="logo">
              <Link to="/">
                <img src="/assets/img/logo/logo.png" alt="logo" />
              </Link>
            </div>

            {/* MENU */}
            <div className="tgmenu__navbar-wrap">
              <ul>
                <li>
                  <NavLink to="/" end>
                    {({ isActive }) => (
                      <span className={`nav-link ${isActive ? "active" : ""}`}>
                        Home
                      </span>
                    )}
                  </NavLink>
                </li>

                <li>
                  <NavLink to="/add-pet">
                    {({ isActive }) => (
                      <span className={`nav-link ${isActive ? "active" : ""}`}>
                        Give a Pet
                      </span>
                    )}
                  </NavLink>
                </li>

                <li>
                  <NavLink to="/my-adoptions">
                    {({ isActive }) => (
                      <span className={`nav-link ${isActive ? "active" : ""}`}>
                        My Adoptions
                      </span>
                    )}
                  </NavLink>
                </li>

                {user?.isAdmin && (
                  <li>
                    <NavLink to="/admin">
                      {({ isActive }) => (
                        <span
                          className={`nav-link ${isActive ? "active" : ""}`}
                        >
                          Admin
                        </span>
                      )}
                    </NavLink>
                  </li>
                )}
              </ul>
            </div>

            {/* RIGHT SIDE */}
            <div className="tgmenu__action">
              <ul className="list-wrap">
                {/* NOTIFICATIONS */}
                <li className="header-btn position-relative" ref={notifRef}>
                  <button
                    className="btn"
                    onClick={() => setOpen((prev) => !prev)}
                  >
                    <i className="fas fa-bell"></i>
                  </button>

                  {unreadCount > 0 && (
                    <span className="notif-badge">
                      {unreadCount > 9 ? "9+" : unreadCount}
                    </span>
                  )}

                  <div className={`tg-notif-dropdown ${open ? "show" : ""}`}>
                    <div className="tg-notif-header">Notifications</div>

                    <div className="tg-notif-list">
                      {notifications.length === 0 ? (
                        <div className="tg-notif-empty">No notifications</div>
                      ) : (
                        notifications.map((n) => (
                          <div
                            key={n.id}
                            className={`tg-notif-item ${
                              !n.is_read ? "unread" : ""
                            }`}
                            onClick={() => markAsRead(n.id)}
                          >
                            <div className="tg-notif-text">{n.message}</div>

                            <div className="tg-notif-time">
                              {new Date(n.created_at).toLocaleString()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </li>

                {/* LOGOUT */}
                <li className="header-btn">
                  <button
                    className="btn"
                    onClick={() => {
                      logout();
                      navigate("/login");
                    }}
                  >
                    Logout
                  </button>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Navbar;
