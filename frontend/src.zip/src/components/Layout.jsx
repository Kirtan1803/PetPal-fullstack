import Navbar from "./Navbar";

function Layout({ children }) {
  return (
    <>
      <Navbar />
      <div className="container py-5">{children}</div>
    </>
  );
}

export default Layout;